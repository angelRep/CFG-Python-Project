# Top Trumps
import random
from typing import Any
import requests
from tkinter import *


def print_line():
    print()


def get_random_pokemon() -> dict[str, Any]:
    pokemon_id = random.randint(1, 151)
    url = "https://pokeapi.co/api/v2/pokemon/{}".format(pokemon_id)
    response = requests.get(url)
    pokemon = response.json()

    return {
        'name': pokemon['name'],
        'id': pokemon['id'],
        'height': pokemon['height'],
        'weight': pokemon['weight'],
    }


def game_round() -> int:
    user_pokemon = get_random_pokemon()
    computer_pokemon = get_random_pokemon()
    selected_stat = ""

    print("Your pokemon with id {} is {} with height {} cm and weights {} kg."
          .format(user_pokemon['id'], user_pokemon['name'],
                  user_pokemon['height'], user_pokemon['weight']))

    selected_stat = input("Select a stat: (id, height, weight) ")
    selected_stat = selected_stat.lower()

    while selected_stat not in ['id', 'height', 'weight']:
        selected_stat = input("Try again! It should be id, height or weight: ")
        selected_stat = selected_stat.lower()

    print_line()

    print("Your opponent's pokemon with id {} is {} with height {} cm and weights {} kg."
          .format(computer_pokemon['id'], computer_pokemon['name'],
                  computer_pokemon['height'], computer_pokemon['weight']))

    print_line()
    print_line()

    if user_pokemon[selected_stat] > computer_pokemon[selected_stat]:
        print("Congratulations! You won!")
    elif user_pokemon[selected_stat] < computer_pokemon[selected_stat]:
        print("You lose...")
    else:
        print("It's a draw!")

    print("Your pokemon's {} is {}."
          .format(selected_stat, user_pokemon[selected_stat]))
    print("Opponent's pokemon's {} is {}."
          .format(selected_stat, computer_pokemon[selected_stat]))


def initial_screen():
    screen = Tk()
    screen.title("TOP TRUMPS")
    screen.geometry("500x500")

    welcome_text = Label(text="Welcome to Top Trumps Game", fg="red", bg="yellow")
    welcome_text.pack()

    click_me = Button(text="START A GAME", fg="red", bg="yellow", command=game_round)
    click_me.place(x=10, y=20)

    screen.mainloop()


#game_round()
initial_screen()
